#ifndef _GPS_H
#define _GPS_H
#endif
#include "sys.h"
void GPRMC_DAT(void);
void GPGSV_DAT(void);
void GPGSA_DAT(void);
void GPGGA_DAT(void);
extern uint8_t TxBuffer1[400]; 
extern uint8_t Rec_Len;


